import React from 'react';

export default function JavaDebuggerUI() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Java Debugger UI</h1>
      <p>This is a placeholder for the web-based debugger interface.</p>
    </div>
  );
}
